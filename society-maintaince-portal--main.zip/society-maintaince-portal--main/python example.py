print("Hello from Python!")
